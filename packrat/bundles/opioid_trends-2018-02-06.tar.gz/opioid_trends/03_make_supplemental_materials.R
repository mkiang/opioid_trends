## Just a simple script that calls the files in ./code/ to recreate the
## supplemental plot and tables

source('./code/11_plot_efigure1.R')

source('./code/12_generate_supp_tables.R')
