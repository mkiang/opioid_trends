## Just a simple script that calls the files in ./code/ to recreate the 
## three plots and two tables in the paper

source('./code/07_plot_figure1.R')

source('./code/08_plot_figure2.R')

source('./code/09_plot_figure3.R')

source('./code/10_generate_tables.R')