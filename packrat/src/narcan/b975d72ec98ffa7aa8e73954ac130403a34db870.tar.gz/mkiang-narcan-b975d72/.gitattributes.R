text=auto
data/* binary
src/* text=lf
R/* text=lf
