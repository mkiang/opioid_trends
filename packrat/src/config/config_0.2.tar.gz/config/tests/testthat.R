library(testthat)
library(config)

test_check("config")
