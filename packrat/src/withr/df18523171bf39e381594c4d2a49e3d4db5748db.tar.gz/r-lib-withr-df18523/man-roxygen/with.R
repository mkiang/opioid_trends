#' @param code \code{[any]}\cr Code to execute in the temporary environment
#' @return \code{[any]}\cr The results of the evaluation of the \code{code}
#'   argument.
#' @seealso \code{\link{withr}} for examples
